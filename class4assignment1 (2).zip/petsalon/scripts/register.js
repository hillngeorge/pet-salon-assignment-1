// Salon information object
let salon = {
    name: "The Fashion Pet",
    phone: "999-999-9999",
    address: {
        street: "palm st",
        number: "1642",
        zip: "89102"
    },
    pets: [  
            {
                name: "scooby",
                age: 50,
                gender: "male",
                service: "grooming",
                breed: "hound"
            },
            {
                name: "scrappy",
                age: 50,
                gender: "male",
                service: "grooming",
                breed: "hound"
            },
            {
                name: "tweetyy",
                age: 80,
                gender: "male",
                service: "grooming",
                breed: "hound"
            }   
    ]

}






// //constructor
// function Pet(n,a,g){
// this.name=n;
// this.age=a;
// this.gender=g;
// }




// DOM elements
const info = document.getElementById("info");
const petTotal = document.getElementById("pet-total");
const petNames = document.getElementById("pet-names");
// Function to calculate and display the total number of pets
function calculatePetTotal() {
    petTotal.innerHTML = `<p>${salon.pets.length}</p>`;
}

calculatePetTotal();
// Function to display pet names
function displayPetNames() {
    let names = "";
    salon.pets.forEach(pet => {
        names += `<p>${pet.name}</p>`;
    });
    petNames.innerHTML = names;
}

displayPetNames();
// Function to display salon information in the footer
function displayFooterInfo() {
    document.getElementById("info").innerHTML = `
        <p>Welcome to the ${salon.name}, the address is: ${salon.address.street} ${salon.address.number} ${salon.address.zip}</p>
    `;
}

displayFooterInfo();
// function register(){
//     //1)getting value

//     //2)create the newPet using the constructor
//     let newPet = new Pet(inputName.value,inputAge.value,inputGender.value);
//     //3 push the newPwet to the array
// salon.pets.push(newPet);

//     //4 call the display function
//     displayPetNames();
    
    
//     //5 clear the input
// inputName.value="";
// inputAge.value="";
// inputGender.value="";
// }




function init(){

let Pet1=new Pet("scooby",60,"Male");
let Pet2=new Pet("scrappy",50,"Male");
let Pet3=new Pet("tiny",40,"Male");
salon.pets.push(Pet1,Pet2,Pet3);
//executing fn
displayPetNames();
}